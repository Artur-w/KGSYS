# Scispacy for Knowledge Graphs

## The project is finaly year project.


## Installation

Create conda environment
`conda create -n myenvironment`


`conda install -c conda-forge spacy`
`conda install -c conda-forge pandas`
`conda install -c conda-forge networkx`
`conda install -c conda-forge scipy`

`pip install visualise_spacy_tree`

`python -m spacy download en_core_web_lg` and
`python -m spacy download en_core_web_sm`

## Run

Run from main folder.
`python code/main.py`